
local agent = ngx.var.http_user_agent

if agent ~= nil then
    local m, ret = ngx.re.match(agent, "Android|webOS|iPhone|iPod|BlackBerry")
    if m ~= nil then
    	ngx.redirect("http://wap.talkmovie.cn"..ngx.var.request_uri, ngx.HTTP_MOVED_TEMPORARILY);
    end
end

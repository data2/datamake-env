local request_uri = ngx.var.request_uri

if not request_uri then return end
local index = string.find(request_uri,'.html');

if index == nil then 
	if request_uri ~= "/" then--首页
		return
	end
end

local redis = require("resty.redis")
local red = redis:new()

red:set_timeout(1000) -- 1 second

local ok,err = red:connect("127.0.0.1",6379)
if not ok then
        ngx.say("failed to connect: ",err)
        return
end

local key = "PV"
local res,err = red:incr(key)
if not res then
	--ngx.say("failed to get ",key,": ",err)
	return
end
--ngx.say("PV:"..res)

local function close_redis(red)  
    if not red then  
        return  
    end  
    --释放连接(连接池实现)  
    local pool_max_idle_time = 10000 --毫秒  
    local pool_size = 100 --连接池大小  
    local ok, err = red:set_keepalive(pool_max_idle_time, pool_size)  
  
    if not ok then  
        ngx_log(ngx_ERR, "set redis keepalive error : ", err)  
    end  
end 
close_redis(red)




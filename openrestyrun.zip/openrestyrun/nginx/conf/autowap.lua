
local agent = ngx.var.http_user_agent

if agent ~= nil then
    local m, ret = ngx.re.match(agent, "Android|webOS|iPhone|iPod|BlackBerry")
    if m ~= nil then
    	#ngx.redirect("https://www.talkmovie.cnss"..ngx.var.request_uri, ngx.HTTP_MOVED_TEMPORARILY);
    else
	ngx.redirect("https://www.talkmovie.cnss"..ngx.var.request_uri, ngx.HTTP_MOVED_TEMPORARILY);
    end
end
